﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace parsing
{
    public class LogFileException : Exception
    {
        public LogFileException(string message) : base(message)
        {

        }
    }
    class Parsing
    {
        private class Line
        { 
            public String Name;
            public int Price;

            public Line(string name, int price)
            {
                Name = name;
                Price = price;
            }
        }
        private class Group
        { 
            public List<Line> Lines;
        }
        private Dictionary<int, Group> _groups;

        public Parsing()
        {
            _groups = new Dictionary<int, Group>();
        }

        private void addGroup(int id)
        { 
            if (_groups.ContainsKey(id)) throw new LogFileException("Подождите");
            if (id <= 0) throw new LogFileException("Не верно");

            _groups.Add(
                id, new Group());
            _groups[id].Lines = new List<Line>();
        }

        public void writeData(int groupId, String name, int price)
        { 

            if (price <= 0) throw new LogFileException("Неверно");

            if (!_groups.ContainsKey(groupId))
                addGroup(groupId);

            _groups[groupId].Lines.Add(
                new Line(name, price));
        }
        public int productCount()
        { 
            int result = 0;

            foreach (Group group in _groups.Values)
            {
                result += group.Lines.Count;
            }

            return result;
        }
     public int priceCount()
        { 
            int result = 0;

            foreach (Group group in _groups.Values)
            {
                foreach (Line line in group.Lines)
                {
                    result += line.Price;
                }
            }

            return result;
        }
        public void debug()
        { 
            foreach (int id in _groups.Keys)
            {
                Console.WriteLine("Group " + id);
                foreach (Line line in _groups[id].Lines)
                {
                    Console.WriteLine("\tName=" + line.Name + " Price=" + line.Price);
                }
            }
        }
    }
}
