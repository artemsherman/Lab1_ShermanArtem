﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace parsing
{
    class Reader
    {
        
        private const string groupIdPattern = @"^Id=\d+$";
        private const string linePattern = @"\t.product=.+, price=\d+.$";
        private const string productPattern = @"\t.product=.+, price"; 
        private const string pricePattern = @"price=\d+.$";
        public static Parsing readDirectory(String path)
        {
            var files = Directory.GetFiles(path, "*.txt");

            if (files.Length == 0) throw new LogFileException("Пусто");

            StreamReader streamReader = new StreamReader(files[0], Encoding.Default);

            Parsing parsing = new Parsing();
            int currentGroup = 0; 

            while (!streamReader.EndOfStream)
            {
                string temp = streamReader.ReadLine();
                if (Regex.IsMatch(temp, groupIdPattern))
                {
                    currentGroup = int.Parse(temp.Split('=')[1]);
                } 
                if (Regex.IsMatch(temp, linePattern))
                { 

                    string product = Regex.Match(temp, productPattern).ToString();
        
                    product = product.Split('=')[1].ToString();
                  
                    product = product.Remove(product.Length - 7);

                    string price = Regex.Match(temp, pricePattern).ToString();

                    price = price.Split('=', ']')[1].ToString();
                    
                    parsing.writeData(currentGroup, product, int.Parse(price));
                    
                }
            }
            return parsing;
        }
    }
}

